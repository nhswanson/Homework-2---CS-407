package com.example.nick.calendar_app;

import android.app.DialogFragment;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CalendarView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by Nick on 3/11/2016.
 */
public class EventActivity extends Activity
{

    public static final String PREFS_NAME = "SavedEvents";
    private static final String EventKey = "key";
    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event);

        SharedPreferences settings = this.getSharedPreferences(PREFS_NAME, 0);
        String loadEvent = settings.getString(EventKey, "");
        TextView text = (TextView) findViewById(R.id.input);
        text.setText(loadEvent);
    }
    public void submitted(View view)
    {
        //save the new event
        SharedPreferences settings = this.getSharedPreferences(PREFS_NAME, 0);
        TextView text = (TextView) findViewById(R.id.input);
        String input = text.getText().toString();
        SharedPreferences.Editor editor = settings.edit();
        editor.putString(EventKey, input);
        editor.commit();
        finish();
    }

    public void cancelled(View view)
    {
        //Close out of window
        finish();
    }

    public void deleted(View view)
    {
        //delete the event (set TextEdit's text field to the empty string)
        SharedPreferences settings = this.getSharedPreferences(PREFS_NAME, 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString(EventKey, "");
        editor.commit();
        finish();
    }
}
